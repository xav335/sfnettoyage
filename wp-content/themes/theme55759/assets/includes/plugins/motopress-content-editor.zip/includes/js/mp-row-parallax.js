jQuery(window).load(function(){jQuery.stellar({horizontalScrolling:!1,verticalScrolling:!0,responsive:!0})});
